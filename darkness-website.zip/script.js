function showMessage() {
  alert("You have stepped deeper into the darkness...");
}
