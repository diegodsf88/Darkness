# Darkness Website

Simple dark-themed website project.

## Features
- Minimalist dark design
- Simple interaction (JavaScript)
- Easy to deploy

## How to Run
Just open `index.html` in your browser.
